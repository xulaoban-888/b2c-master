create view cid3 as
select `b2c`.`tb_category`.`parent_id` AS `parent_id`
from `b2c`.`tb_category`
group by `b2c`.`tb_category`.`parent_id`;

